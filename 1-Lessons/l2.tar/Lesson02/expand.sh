#!/bin/bash
unzip engr1330-layout.zip;
mv ./engr1330_layout/OriginalPowerpoint ./
mv ./engr1330_layout/PsuedoLesson ./
mv ./engr1330_layout/index.html ./
mv ./engr1330_layout/styles.css ./
rm -rf engr1330_layout.zip
rm -rf engr1330_layout
rm -rf _MACOSX


